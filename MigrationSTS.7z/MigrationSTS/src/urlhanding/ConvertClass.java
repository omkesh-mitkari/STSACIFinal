/*package urlhanding;
import org.apache.struts.action.*;
import java.io.*;
import java.util.Scanner;

public class ConvertClass {
	public static void processActionClass() throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		String rootDirectory;
		
		System.out.println("Enter the path of root directory containing Action Classes");
		Scanner sc = new Scanner(System.in);
		rootDirectory = sc.nextLine();
		rootDirectory = "C:\\Users\\khanars\\Desktop\\ActionClasses";
		handleDirectory(rootDirectory);
	}
	
	static void handleDirectory(String myDirectoryPath) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException{
		int i,exitFlag;
		char ch;
		String buffer = "";
	
		File dir = new File(myDirectoryPath);		
		File[] directoryListing = dir.listFiles();
		
		System.out.println("Root dir path:"+myDirectoryPath);
		
		if(directoryListing != null){
			for(File subDirectory : directoryListing){
				if(subDirectory.isDirectory()){
					//System.out.println("name of dir:"+String.valueOf(subDirectory));
					handleDirectory(String.valueOf(subDirectory));
				}
				else{
					FileInputStream fin = new FileInputStream(subDirectory);
		
		//****************************************************************			
		//only the filename instead of myDirectoryPath should be provided
			System.out.println("subdir:"+subDirectory);		
					String fileName = getFileName(String.valueOf(subDirectory),'\\');
			System.out.println("Filename is:"+fileName);		
					Class<?> obj = Class.forName(fileName);
					Object classObject = obj.newInstance();
					
					//Class<?> obj2 = org.apache.struts.action.Action.class;
					//if (classObject instanceof org.apache.struts.action.Action)
						
						
			System.out.println("reading file :"+subDirectory);		
					while((i = fin.read()) != -1){
						ch = (char)i;
						if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')){
							if(buffer.equals("extends")){
				//	System.out.println("equals extends");		
								buffer = "";
								exitFlag = 0;
								while((i = fin.read()) != -1){
									ch = (char)i;
									if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '.')){
										if((buffer.equals("Action")) || ((classObject instanceof org.apache.struts.action.Action))){										
											System.out.println("converting file :"+subDirectory);			
															convertClasses(subDirectory);
															break;
														}
										else if(ch == '\n'){
											exitFlag = 1;
											break;
										}
										else{
											buffer = "";
										}
										
									}
									else{
										buffer += ch;
									}
								}
								if(exitFlag == 1){
									break;
								}
							}
							else{
								buffer = "";
							}
						}
						else{
							buffer += ch;
						}
					}
					fin.close();
				}
			}
		}
		
	}
	
	static void convertClasses(File subDirectory) throws IOException{
		String buffer = "";
		String mappingVariable=null;		//to store ActionMapping type variable
		String formName = null;
		char ch;
		int i;
		int tab_count = 0;
		byte b[];
		
			FileInputStream fin = new FileInputStream(subDirectory);
			File outputFile = new File("spring/"+subDirectory);
			outputFile.getParentFile().mkdirs();
			FileOutputStream fout = new FileOutputStream(outputFile);
	
			//FileInputStream fin = new FileInputStream("ActionClass.java");
			//FileOutputStream fout = new FileOutputStream("spring/ActionClass.java");
			
			
			while((i=fin.read()) != -1) {
				ch = (char)i;
				if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')) {		//delimites
					
					//if word is ActionForward replace with String
					if(buffer.equals("ActionForward")) {		
						replaceActionForward(fin,fout);
						buffer = "";
					}
					//if word is extends remove it and next word
					else if(buffer.equals("extends")) {	
						removeExtends(fin,fout);
						buffer = "";
					}
					//removing all the libraries and packages
					else if(buffer.equals("import")) {	
						buffer = "";
						while((i = fin.read()) != -1) {
							ch = (char)i;
							if(ch == '.') {
								if(buffer.equals("org.apache.struts")){		
									//ignore the line until end of line	
									while((i = fin.read()) != -1){
										ch = (char)i;
										if(ch == '\n'){
											break;
										}
									}		
									break;
								}
								else{		
									buffer += ch;
								}
							
							}
							else if(ch == '\n'){
								buffer = "import "+buffer+ch;
								//System.out.print(buffer);
								b = buffer.getBytes();
								fout.write(b);
								break;
							}
							else{
								buffer += ch;
							}
						}		
						buffer = "";
					}
						//if word is ActionMapping store its variable
					else if(buffer.equals("ActionMapping")) {
						mappingVariable = storeMappingVariable(fin,fout);			
						buffer = "";
					}
						//storing ActionForm name
					else if(buffer.equals("ActionForm")) {
						formName = getFormName(fin,fout);
					//	System.out.println("form name:"+formName);			
						buffer = "";
					}
					//dealing with ActionForm
					//returning only strings instead of map.findForward("String)						
					else if((mappingVariable != null) && (buffer.equals(mappingVariable+".findForward"))) {	
						replaceFindForward(fin,fout);
						buffer = "";
					}
					
					else{		
						buffer += ch;
						indentTab(fout,tab_count);
						tab_count = 0;				
						b = buffer.getBytes();
						fout.write(b);				
						if(ch == '\n'){
						
							//System.out.println(buffer);
							buffer += '\n';
						}
						else{
						//System.out.print(buffer);
						}
						
						buffer = "";
						
					}
					
				}
				else if(ch == '\t'){
					tab_count++;
				}
				else{	
					buffer += ch;
				}
			}
			fin.close();
			fout.close();
}
	
	static void indentTab(FileOutputStream fout,int tab_count) throws IOException{
		byte b[];
		String buffer = "";
		
		buffer += '\t';
		b = buffer.getBytes();
		while(tab_count > 0){
			System.out.print('\t');
			fout.write(b);
			tab_count--;
		}
	}

	static void replaceActionForward(FileInputStream fin,FileOutputStream fout) throws IOException{
		byte b[];
		String buffer = "String ";
		
		b = buffer.getBytes();
		fout.write(b);
		//System.out.print("String ");
	}
	
	static void removeExtends(FileInputStream fin,FileOutputStream fout) throws IOException {
		ignoreUntil(fin,fout,"Action");
	}
	
	static void ignoreUntil(FileInputStream fin,FileOutputStream fout,String str) throws IOException {		//ignores everything till String 'str'
		String buffer = "";
		char ch = ' ';
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == '.')) {
				if(buffer.equals(str)) {
					break;
				}
				else{
					buffer = "";
				}
			}
			else if(ch == '\t'){
				//ignore
			}
			else {		
				buffer += ch;
			}
		}
		//System.out.print(ch);
		buffer = "";
		buffer += ch;
		b = buffer.getBytes();
		fout.write(b);
	}
	
	static String storeMappingVariable(FileInputStream fin,FileOutputStream fout) throws IOException {
		String buffer = "";
		char ch;
		int i;
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')) {
				//System.out.print("ActionMapping "+buffer+ch);
				break;
			}
			else {
				buffer += ch;
			}
		}
		return buffer;
		
	}
	
	static String getFormName(FileInputStream fin,FileOutputStream fout) throws IOException {
		String buffer = "";
		String temp_buffer = "";
		char ch;
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')) {
				//System.out.print("ActionForm "+buffer+ch);
				temp_buffer = "ActionForm "+buffer+ch;
				b = temp_buffer.getBytes();
				fout.write(b);
				break;
			}
			else {
				buffer += ch;
			}
		}
		return buffer;
		
	}
	
	static void replaceFindForward(FileInputStream fin,FileOutputStream fout) throws IOException {
		String buffer = "";
		char ch;
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if(ch == '(') {
				//ignore
			}
			else if(ch == ')') {
				//System.out.print(buffer);
				b = buffer.getBytes();
				fout.write(b);
				break;
			}
			else {
				buffer += ch;
			}
		}
	}
	
	static String getFileName(String directoryPath,char separator){
		int i;
		String buffer = "";
		
		for(i=0;i<directoryPath.length();i++){
			if(directoryPath.charAt(i) == separator){
				buffer = "";
			}
			else{
				buffer += directoryPath.charAt(i);
			}
		}
		
		return buffer;
		
	}

}

*/

package urlhanding;
import java.io.*;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;

public class ConvertClass {
	private static String outputRootDirectory = "",rootDirectory = "";
	public static int count_classes=0;
	public static Set<String> hash_Set =new HashSet<String>();
	public static void processActionClass() throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
	//	String rootDirectory;
	try{
		
		hash_Set = xmlparser.getUniqueClasses();
		
		System.out.println("Enter the path of root directory containing Action Classes");
		Scanner sc = new Scanner(System.in);
		rootDirectory = sc.nextLine();
		outputRootDirectory = getOutputRootDirectory(rootDirectory,'\\');
		System.out.println("outputrootdir:"+outputRootDirectory);	
		
		handleDirectory(rootDirectory,hash_Set);
		
		System.out.println("No of Classes processed="+count_classes);
		
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	
	
	public static String processsubDirectory(String stringsubDirectory)
	{
		
		String fileName = StringUtils.substringAfter(stringsubDirectory, "com");
		fileName=StringUtils.substringBeforeLast(fileName, ".java");
		int length = fileName.length();
		char[] processed = new char[length+3];
		processed[0]='c';
		processed[1]='o';
		processed[2]='m';
		for(int i=0;i<length;i++)
		{
			if(fileName.charAt(i)=='\\')
			{
				processed[i+3]='.';
			}
			else
			{
				processed[i+3]=fileName.charAt(i);
			}
			
		}
		String result = String.valueOf(processed);
		System.out.println(result);
		return result;
	}
	static void handleDirectory(String myDirectoryPath,Set<String> hash_Set) throws IOException{
		
		int i,exitFlag;
		char ch;
		String buffer = "";
	try{
		File dir = new File(myDirectoryPath);		
		File[] directoryListing = dir.listFiles();
		
		if(directoryListing != null){
			for(File subDirectory : directoryListing){
				if(subDirectory.isDirectory()){
					//System.out.println("name of dir:"+String.valueOf(subDirectory));
					handleDirectory(String.valueOf(subDirectory),hash_Set);
				}
				else{
					String stringsubDirectory = String.valueOf(subDirectory);
					String packageName=processsubDirectory(stringsubDirectory);
					if(hash_Set.contains(packageName))
					{
						System.out.println("Entered in the match");
						FileInputStream fin = new FileInputStream(subDirectory);
						count_classes++;
						convertClasses(subDirectory);
					fin.close();
					}
				}
			}
		}
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		
	}
	
	static void convertClasses(File subDirectory) throws IOException{
		String buffer = "";
		String filename = null;
		String mappingVariable=null;		//to store ActionMapping type variable
		String formName = null;
		char ch;
		int i;
		boolean importFlag = false;
		int tab_count = 0;
		byte b[];	
		
			FileInputStream fin = new FileInputStream(subDirectory);
			
	System.out.println("subdir:"+subDirectory);	
			String internalDirectory = getInternalDirectory(String.valueOf(subDirectory),'\\');
	System.out.println("internal dir:"+internalDirectory);		
			String finalOutputPath = outputRootDirectory + internalDirectory;
	System.out.println("outputRootDir:"+outputRootDirectory);		
	System.out.println("outputdirectory:"+finalOutputPath);
			File outputFile = new File(finalOutputPath);
			outputFile.getParentFile().mkdirs();
			FileOutputStream fout = new FileOutputStream(outputFile);
	
			//FileInputStream fin = new FileInputStream("ActionClass.java");
			//FileOutputStream fout = new FileOutputStream("spring/ActionClass.java");
			
			
			while((i=fin.read()) != -1) {
				ch = (char)i;
				if(ch == '\n'){
					buffer += ch;
					b = buffer.getBytes();
					fout.write(b);
					buffer = "";
				}
				else{
					buffer += ch;
				}
					
				/*if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')) {		//delimites 
					//if word is ActionForward replace with String
					if(buffer.equals("ActionForward")) {		
						replaceActionForward(fin,fout);
						buffer = "";
					}
					//if word is extends remove it and next word
					else if(buffer.equals("extends")) {	
						removeExtends(fin,fout);
						buffer = "";
					}
					//removing all the libraries and packages
					else if(buffer.equals("import")) {	
						buffer = "";
						while((i = fin.read()) != -1) {
							ch = (char)i;
							if(ch == '.') {
								if(buffer.equals("org.apache.struts")){		
									//ignore the line until end of line	
									while((i = fin.read()) != -1){
										ch = (char)i;
										if(ch == '\n'){
											break;
										}
									}		
									break;
								}
								else{		
									buffer += ch;
								}
							
							}
							else if(ch == '\n'){
								buffer = "import "+buffer+ch;
								//System.out.print(buffer);
								b = buffer.getBytes();
								fout.write(b);
								break;
							}
							else{
								buffer += ch;
							}
						}		
						buffer = "";
						
						//import org.apache.struts.action once
						if(!importFlag){
							buffer = "import org.apache.struts.action.*;";
							buffer += '\n';
							b = buffer.getBytes();
							fout.write(b);
							importFlag = true;
							buffer = "";
						}
					}
						//if word is ActionMapping store its variable
					else if(buffer.equals("ActionMapping")) {
						mappingVariable = storeMappingVariable(fin,fout);			
						buffer = "";
					}
						//storing ActionForm name
					else if(buffer.equals("ActionForm")) {
						formName = getFormName(fin,fout);
					//	System.out.println("form name:"+formName);			
						buffer = "";
					}
					//dealing with ActionForm
					//returning only strings instead of map.findForward("String)						
					else if((mappingVariable != null) && (buffer.equals(mappingVariable+".findForward"))) {	
						replaceFindForward(fin,fout);
						buffer = "";
					}
					
					//removing mappingVariables
					else if(buffer.equals(mappingVariable)){
						buffer = "";
					}
					
					else{		
						buffer += ch;		
						indentTab(fout,tab_count);
						tab_count = 0;				
						b = buffer.getBytes();
						fout.write(b);				
						buffer = "";
						
					}
					
				}
				else if(ch == '\t'){
					if(!buffer.equals("")){
						indentTab(fout,tab_count);
						tab_count = 0;				
						b = buffer.getBytes();
						fout.write(b);				
						buffer = "";
					}
					tab_count++;
				}
				else{	
					buffer += ch;
				}*/
			}
			fin.close();
			fout.close();
}
	
	static void indentTab(FileOutputStream fout,int tab_count) throws IOException{
		byte b[];
		String buffer = "";
		
		buffer += '\t';
		b = buffer.getBytes();
		while(tab_count > 0){
			System.out.print('\t');
			fout.write(b);
			tab_count--;
		}
	}

	static void replaceActionForward(FileInputStream fin,FileOutputStream fout) throws IOException{
		byte b[];
		String buffer = "String ";
		
		b = buffer.getBytes();
		fout.write(b);
		//System.out.print("String ");
	}
	
	static void removeExtends(FileInputStream fin,FileOutputStream fout) throws IOException {
		
		String buffer ="extends ",tempBuffer = "";
		byte b[];
		
		tempBuffer = ignoreUntil(fin,fout,"Action");
		//'Action' is not present after extends keyword		
		if(tempBuffer != null){
			buffer += tempBuffer + '\n';
			b = buffer.getBytes();
			fout.write(b);
			System.out.print(buffer);
		}
	}
	
	static String ignoreUntil(FileInputStream fin,FileOutputStream fout,String str) throws IOException {		//ignores everything till String 'str'
		String buffer = "",permanentBuffer="";
		char ch = ' ';
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			permanentBuffer += ch;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == '.')) {
				if(buffer.equals(str)) {
					break;
				}
				//return if there's no Action keyword
				else if(ch == '\n'){
					return permanentBuffer;
				}
				else{
					buffer = "";
				}				
				
			}
			else if(ch == '\t'){
				//ignore
			}
			else {		
				buffer += ch;
			}
		}
		//System.out.print(ch);
		buffer = "";
		buffer += ch;
		b = buffer.getBytes();
		fout.write(b);
		
		//if there's 'Action' present after extends
		return null;
	}
	
	static String storeMappingVariable(FileInputStream fin,FileOutputStream fout) throws IOException {
		String buffer = "";
		char ch;
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if(ch == ' '){
				continue;
			}
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')) {
				//System.out.print("ActionMapping "+buffer+ch);
				break;
			}
			else {
				buffer += ch;
			}
		}
		return buffer;
		
	}
	
	static String getFormName(FileInputStream fin,FileOutputStream fout) throws IOException {
		String buffer = "";
		String temp_buffer = "";
		char ch;
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')) {
				//System.out.print("ActionForm "+buffer+ch);
				temp_buffer = "ActionForm "+buffer+ch;
				b = temp_buffer.getBytes();
				fout.write(b);
				break;
			}
			else {
				buffer += ch;
			}
		}
		return buffer;
		
	}
	
	static void replaceFindForward(FileInputStream fin,FileOutputStream fout) throws IOException {
		String buffer = "";
		char ch;
		int i,bracketCount = 0;
		int tab_count = 0;
		byte b[];
		
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			
			 if((ch == '(')){
			//	System.out.println("**********************************************");			

				bracketCount++;
				buffer += ch;	
			}
			else if((ch == ')') && (bracketCount == 0)) {
				//System.out.print(buffer);
				b = buffer.getBytes();
				fout.write(b);
				break;
			}
			else if(ch == ')'){
				bracketCount--;
				buffer += ch;
			}
			else {
				buffer += ch;
			}
		}
	}
	
	static String getOutputRootDirectory(String inputDirectory,char fileSeparator){
		String preDirectory = "", postDirectory = "",outputDirectory = "";
		int i,len;
		
		for(i = 0 ; i < inputDirectory.length();i++) {
			/*if(inputDirectory.charAt(i) == fileSeparator) {
				preDirectory += fileSeparator+postDirectory;
				postDirectory = "";
			}
			else {
				postDirectory += inputDirectory.charAt(i);
			}
			*/
			if(inputDirectory.charAt(i) == fileSeparator){
				i++;
				break;
			}
			else{
				preDirectory += inputDirectory.charAt(i);
			}
		}
		
		for(; i < inputDirectory.length();i++){
			postDirectory += inputDirectory.charAt(i);
		}
		
		outputDirectory = preDirectory + fileSeparator + "input_spring" + fileSeparator + postDirectory + fileSeparator;
		
		//returning with file separator at the end
		return outputDirectory;
	}
	
	static String getInternalDirectory(String inputDirectory,char fileSeparator){
		int i;
		String outputDirectory = "";
		
		i = rootDirectory.length();
		System.out.println("len of rootdir:"+i);
		System.out.println("input at i:"+inputDirectory.charAt(i));
		if(inputDirectory.charAt(i) == fileSeparator){
			i++;
		}
		
		for(;i<inputDirectory.length();i++){
			outputDirectory += inputDirectory.charAt(i);
		}
		
		//returning without fileSeparator at the start
		return outputDirectory;
	}
}
