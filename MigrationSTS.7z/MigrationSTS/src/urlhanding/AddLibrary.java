package urlhanding;

import java.io.*;

public class AddLibrary
{
    public static void addJars(String srcPath,String destPath)
    {
        File srcFolder = new File(srcPath);
        File destFolder = new File(destPath);

        if(!srcFolder.exists())
        {

              System.out.println("Directory does not exist.");
               //just exit
             System.exit(0);
        }
        else{

               try{
                    copyDirectory(srcFolder,destFolder);
                          }
               catch(IOException e)
                {
                        e.printStackTrace();
                        //error, just exit
                            System.exit(0);
                    }
            }
        System.out.println("Done");
    }

    public static void copyDirectory(File src , File target) throws IOException 
    {
        if (src.isDirectory()) 
        {
                if (!target.exists()) 
            {
                    target.mkdir();
                }

                String[] children = src.list();
                for (int i=0; i<children.length; i++) 
            {
                     copyDirectory(new File(src, children[i]),new File(target, children[i]));
                }
        }
        // if Directory exists then only files copy
        else 
        {

                InputStream in = new FileInputStream(src);
                OutputStream out = new FileOutputStream(target);

                // Copy the bits from instream to outstream
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) 
            {
                        out.write(buf, 0, len);
            }
            in.close();
                out.close();

            }


    }    

}