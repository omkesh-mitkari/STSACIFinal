package urlhanding;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ValidatorParsing {
	public static Hashtable<String,String> h3 = new Hashtable<String,String>();
	public static Properties properties = new Properties();
	
	public static String process_list(List<String> L1)
	{
		String Value="";
		for(int i=0;i<L1.size();i++)
		{
			Value=Value.concat(L1.get(i));
			Value+=",";
		}
		return Value;
	}
	public static void getValidatorMappings()
	{
		try
		 {
		File inputFile = new File("C:\\Users\\mitkario\\Downloads\\CORP_BANK_SRC\\banking_web\\WebContent\\WEB-INF/bank-validation.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        
        Document doc = dBuilder.parse(inputFile);
        
        doc.getDocumentElement().normalize();
        
        //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        
        NodeList nList = doc.getElementsByTagName("form");
        
        System.out.println("----------------------------");
        
        for (int temp = 0; temp < nList.getLength(); temp++) {
           Node nNode = nList.item(temp);
           System.out.println("\nCurrent Element :" + nNode.getNodeName());
           List<String> L= new ArrayList<String>();
           if (nNode.getNodeType() == Node.ELEMENT_NODE) {
              Element eElement = (Element) nNode;
              //System.out.println(eElement.getAttribute("name"));
              String type=eElement.getAttribute("name");
              NodeList nList1 =eElement.getElementsByTagName("field");
              //String value=process_list(nList1); 
              for(int temp1=0;temp1<nList1.getLength();temp1++)
              {
            	  Node nNode1 = nList1.item(temp1);
              	  Element eElement1 =(Element) nNode1;
            	  L.add(eElement1.getAttribute("property"));
              }
              String value=process_list(L);
              properties.put("validation."+eElement.getAttribute("name")+".validator.fields", value);
              for(int temp1=0;temp1<nList1.getLength();temp1++)
              {
            	  Node nNode1 = nList1.item(temp1);
              	  Element eElement1 =(Element) nNode1;
              	  properties.put("validation."+eElement.getAttribute("name")+".validator."+eElement1.getAttribute("property"), eElement1.getAttribute("depends"));
              }
           }
		 }
        try
        {
        	File file = new File("bank-validations.properties");
			FileOutputStream fileOut = new FileOutputStream(file);
			properties.store(fileOut, "JSP Mappings");
			fileOut.close();
        }
        catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		 }
		 catch (Exception e) {
	         e.printStackTrace();
	      }
	}
}
