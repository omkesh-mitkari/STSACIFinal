package urlhanding;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.List;

public class ToolClass {
	public static void CreateDirectory()
	{
		//FileStructure fileStructure = new FileStructure();
		FileStructure.createDirectoryStructure();
		System.out.println("Directory Structure created successfully....\n");
	}
	
	public static void AddLibraries()
	{
		//AddLibrary addLibrary = new AddLibrary();
		AddLibrary.addJars("C:\\Users\\Admin\\Desktop\\Project Phase1\\SpringJars", "C:\\Users\\Admin\\Desktop\\Project\\Struts\\WebContent\\WEB-INF\\lib");
		System.out.println("Jars Added to lib folder successfully....\n");
	}
	
	
	public static void XmlParser() throws IOException
	{
		//WebXMLParser webXMLParser = new WebXMLParser();
		WebXMLParser.convertWebXML();	
	}
	
	public static void ConvertClasses() throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{

		//ConvertClass convertClass = new ConvertClass();
		ConvertClass.processActionClass();
	}
	
	public static void FormBeans() throws IOException 
	{
		//FormClassConversion formClassConversion = new FormClassConversion();
	    FormClassConversion.convertFormBean();		
	}
	public static void test() throws IOException
	{
		Hashtable<String,List<String>> h1 = new Hashtable<String,List<String>>();
		h1=xmlparser.getForwardMappings();
		CreateController.craete_property_file(h1);
	}
	public static void test1() throws IOException
	{
		String output="";
		output=JspUrlUtility.getPath("success_preview,achLimitsCompanyAccount,error,addNewAchCompanyAccount,failure,/csr/common/corp/accounts/accountSearch,accountSearchFailure,/csr/accountSearch,", "error");
		System.out.println(output);
	}
	public static void Dispatcher_Servelet() throws IOException
	{
		FileWriter fstream12 = new FileWriter("C:\\Users\\Admin\\Desktop\\Project\\Struts\\WebContent\\WEB-INF/project-sevelet.xml", true);
		BufferedWriter out12 = new BufferedWriter(fstream12);
		CreateController.addDispatcherServelet(fstream12,out12);
		out12.close();
	}
	
	public static void ControllerCreation() throws IOException
	{
		CreateController.Controller();
	}
	
	public static void Files()  throws Exception
	{
		Files.move(Paths.get("C:\\Users\\Admin\\Desktop\\STS\\STSTool\\urlhanding/ConvertActionForm.java"),Paths.get("C:\\Users\\Admin\\Desktop/Project/Spring/src/com/project/SupportFiles/ConvertActionForm.java"));
		Files.move(Paths.get("C:\\Users\\Admin\\Desktop\\STS\\STSTool\\urlhanding/formHelper.java"),Paths.get("C:\\Users\\Admin\\Desktop/Project/Spring/src/com/project/SupportFiles/formHelper.java") );
	}
	
	public static void test2() throws IOException
	{
		xmlparser.getUniqueClasses();
	}
	public static void test3() throws IOException
	{
		ConvertClass.processsubDirectory("C:\\Users\\mitkario\\Downloads\\banking_core\\src\\java\\com\\s1\\emea\\disbursement\\common\\ui\\ReourceKeys.java");
	}
	public static void test4() throws IOException
	{
		ValidatorParsing.getValidatorMappings();
	}
	public static void SwitchCase(String ch) throws Exception
	{
	
		switch(ch)
		{
			case "1":
				CreateDirectory();
				break;
			case "2":
				AddLibraries();
				break;
			case "3":
				XmlParser();
				break;
			case "4":
				ConvertClasses();
				break;
			case "5":
				FormBeans();
				break;
			case "6": 
				Dispatcher_Servelet();
				break;
			case "7":
				ControllerCreation();
				break;
			case "8":
				Files();
				break;
			case "9":
				test();
				break;
			case "10":
				test1();
				break;
			case "11":
				test2();
				break;
			case "12":
				test3();
				break;
			case "13":
				test4();
				break;
			default:
				break;
		}
	}
}
